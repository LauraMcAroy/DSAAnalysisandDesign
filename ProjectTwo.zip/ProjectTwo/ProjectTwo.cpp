// ProjectTwo.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Laura McAroy

#include <iostream>
#include <fstream>
#include <string>

#include <vector>
using namespace std;



struct Course {
    string courseName;
    string courseNumber;
    vector<string> totalPrereqs;
};
// Utilizing tokenize to split lines by delimiter 
vector<string> tokenize(string s, string del = " ") {
    vector<string> stringArray;
    int start = 0;
    int end = s.find(del);
    while (end != -1) {
        stringArray.push_back(s.substr(start, end - start));
        start = end + del.size();
        end = s.find(del, start);
    }
    stringArray.push_back(s.substr(start, end - start));

    return stringArray;
}
//Open and read file
vector<Course> LoadDataStructure() {
//Open text file and create vector
    ifstream fin("abcu.txt");
    vector<Course> courses;
    string line;

    while (getline(fin, line)) {
     //Creates a new entry in empty vector
        courses.push_back(Course());
    /** The next line here in order to read courses
    needs to be 
    
    courses.push_back(line)
    
    However, when I insert that line it throws an overloading error
    I cant figure out how to correct!! **/
        
        
        
    }
    
    Course course;
    
 // Calling function to split and store course information
        vector<string> courseInformation = tokenize(line, ",");

        course.courseNumber = courseInformation[0];
        course.courseName = courseInformation[1];
  //If there is a prerequisite, store it    
        for (int i = 2; i < courseInformation.size(); i++) {
            course.totalPrereqs.push_back(courseInformation[i]);
        }
//Add course to list
        courses.push_back(course);


        return courses;
    }


    void printCourseInfo(Course course) {
        string courseNumber = course.courseNumber;
        string courseName = course.courseName;
        vector<string> totalPrereqs = course.totalPrereqs;

        cout << "Course Number: " << courseNumber << endl;
        cout << "Course Name: " << courseName << endl;
        cout << "Prerequisites: ";
        //Loops through prerequisites and prints them all
        for (int i = 0; i < totalPrereqs.size(); i++) {
            cout << totalPrereqs[i] << " ";
        }
        cout << endl;
        cout << endl;

}
    void printCourseList(vector<Course> courses) {
        //using bubble sort to sort list alphabetically   
        int n = courses.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (courses[j].courseNumber > courses[j + 1].courseNumber) {
                    swap(courses[j + 1], courses[j]);
                }
            }
        }
        //traverse list and print
        for (int i = 0; i < n; i++) {
            printCourseInfo(courses[i]);
        }
    }
    void searchCourse(vector<Course> courses) {
        string courseNumber;

        cout << "Enter the course number:";
        cin >> courseNumber;
//Searches through courses for matching coursenumber
        for (int i = 0; i < courses.size(); i++) {
            if (courses[i].courseNumber == courseNumber) {
        //Calls print function to print course info
                printCourseInfo(courses[i]);
            }
            else {
                cout << "Course not found.";
            }
        }
    }

int main() {
    int userinput = 0;
    vector<Course> courses;

//Menu display
    cout << "Course Planner Menu" << endl << endl;
    cout << "1. Load Courses" << endl;
    cout << "2. Print Course List" << endl;
    cout << "3. Print Course" << endl;
    cout << "4. Exit" << endl;

    cin >> userinput;

    while (userinput >=1 && userinput <=4){
//Ends program
        if (userinput == 4) {
        cout << "Goodbye." << endl;
        break;
        }
       
    //Creates new menu display after courses are loaded
        else if (userinput == 1) {
            courses = LoadDataStructure();
            cout << "Courses loaded." << endl << endl;
            cout << "Course Planner Menu" << endl << endl;
            cout << "2. Print Course List" << endl;
            cout << "3. Print Course" << endl;
            cout << "4. Exit" << endl;
            cin >> userinput;
        }
        else if (userinput == 2) {
                printCourseList(courses);
                cin >> userinput;
            }
        else if (userinput == 3) {
                searchCourse(courses);
                cin >> userinput;
            }
         else {
                cout << "Invalid Choice. Please select option 2-4." << endl;
                cin >> userinput;
            }

            }
    }




